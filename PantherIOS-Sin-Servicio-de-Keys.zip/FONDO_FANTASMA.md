Fondo de Patches actualizado con la imagen de fantasma proporcionada. Asset: GhostPatchesBackground. Vista principal: PatchProjectsView en ThreeOneOSFive/views/PatchProjectsView.swift.
